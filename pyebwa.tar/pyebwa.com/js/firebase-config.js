// Firebase configuration
// IMPORTANT: Replace these values with your actual Firebase config
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize services
const auth = firebase.auth();
const db = firebase.firestore();

// Auth state observer
auth.onAuthStateChanged((user) => {
    if (user) {
        // User is signed in
        console.log('User signed in:', user.email);
        // Store user session
        sessionStorage.setItem('pyebwaUser', JSON.stringify({
            uid: user.uid,
            email: user.email,
            displayName: user.displayName
        }));
    } else {
        // User is signed out
        console.log('User signed out');
        sessionStorage.removeItem('pyebwaUser');
    }
});