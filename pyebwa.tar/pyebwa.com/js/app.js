// Translations
const translations = {
    en: {
        tagline: "Your Family Roots",
        login: "Login",
        signup: "Sign Up",
        heroTitle: "Keep Your Family History Alive",
        heroSubtitle: "Create your family tree, share stories, and connect generations",
        getStarted: "Get Started Now",
        featuresTitle: "Why Pyebwa?",
        feature1Title: "Build Your Tree",
        feature1Desc: "Add family members, photos, and important dates easily",
        feature2Title: "Share Stories",
        feature2Desc: "Preserve memories and family stories for future generations",
        feature3Title: "Connect Family",
        feature3Desc: "Find and connect with family members everywhere",
        loginTitle: "Login to Pyebwa",
        signupTitle: "Create Pyebwa Account",
        email: "Email",
        password: "Password",
        confirmPassword: "Confirm Password",
        fullName: "Full Name",
        loginButton: "Login",
        createAccountButton: "Create Account",
        noAccount: "Don't have an account?",
        createAccount: "Create one",
        haveAccount: "Already have an account?",
        loginLink: "Login",
        allRights: "All rights reserved."
    },
    fr: {
        tagline: "Vos Racines Familiales",
        login: "Connexion",
        signup: "S'inscrire",
        heroTitle: "Gardez Votre Histoire Familiale Vivante",
        heroSubtitle: "Créez votre arbre généalogique, partagez des histoires et connectez les générations",
        getStarted: "Commencer Maintenant",
        featuresTitle: "Pourquoi Pyebwa?",
        feature1Title: "Construisez Votre Arbre",
        feature1Desc: "Ajoutez des membres de la famille, des photos et des dates importantes facilement",
        feature2Title: "Partagez des Histoires",
        feature2Desc: "Préservez les souvenirs et les histoires familiales pour les générations futures",
        feature3Title: "Connectez la Famille",
        feature3Desc: "Trouvez et connectez-vous avec des membres de la famille partout",
        loginTitle: "Connexion à Pyebwa",
        signupTitle: "Créer un Compte Pyebwa",
        email: "Courriel",
        password: "Mot de passe",
        confirmPassword: "Confirmer le mot de passe",
        fullName: "Nom complet",
        loginButton: "Se connecter",
        createAccountButton: "Créer un compte",
        noAccount: "Pas de compte?",
        createAccount: "Créez-en un",
        haveAccount: "Vous avez déjà un compte?",
        loginLink: "Connexion",
        allRights: "Tous droits réservés."
    },
    ht: {
        tagline: "Rasin Fanmi w",
        login: "Konekte",
        signup: "Enskri",
        heroTitle: "Kenbe Istwa Fanmi w Vivan",
        heroSubtitle: "Kreye pyebwa fanmi w, pataje istwa, epi konekte jenerasyon yo",
        getStarted: "Kòmanse Kounye a",
        featuresTitle: "Poukisa Pyebwa?",
        feature1Title: "Bati Pyebwa w",
        feature1Desc: "Ajoute manm fanmi, foto, ak dat enpòtan yo fasil",
        feature2Title: "Pataje Istwa",
        feature2Desc: "Prezève memwa ak istwa fanmi pou jenerasyon k ap vini yo",
        feature3Title: "Konekte Fanmi",
        feature3Desc: "Jwenn ak konekte ak fanmi ou toupatou",
        loginTitle: "Konekte nan Pyebwa",
        signupTitle: "Kreye Kont Pyebwa",
        email: "Imèl",
        password: "Mo pas",
        confirmPassword: "Konfime mo pas",
        fullName: "Non konplè",
        loginButton: "Konekte",
        createAccountButton: "Kreye Kont",
        noAccount: "Pa gen kont?",
        createAccount: "Kreye youn",
        haveAccount: "Gen kont deja?",
        loginLink: "Konekte",
        allRights: "Tout dwa rezève."
    }
};

// Current language
let currentLang = 'ht';

// DOM Elements
const modalOverlay = document.getElementById('modalOverlay');
const loginModal = document.getElementById('loginModal');
const signupModal = document.getElementById('signupModal');
const loginBtn = document.getElementById('loginBtn');
const signupBtn = document.getElementById('signupBtn');
const ctaBtn = document.getElementById('ctaBtn');
const closeLogin = document.getElementById('closeLogin');
const closeSignup = document.getElementById('closeSignup');
const switchToSignup = document.getElementById('switchToSignup');
const switchToLogin = document.getElementById('switchToLogin');
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');

// Language switching
document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelector('.lang-btn.active').classList.remove('active');
        e.target.classList.add('active');
        currentLang = e.target.dataset.lang;
        updateLanguage();
    });
});

function updateLanguage() {
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.dataset.i18n;
        if (translations[currentLang][key]) {
            element.textContent = translations[currentLang][key];
        }
    });
}

// Modal functions
function showModal(modal) {
    modalOverlay.classList.add('active');
    modal.classList.add('active');
}

function hideModal(modal) {
    modalOverlay.classList.remove('active');
    modal.classList.remove('active');
}

function hideAllModals() {
    hideModal(loginModal);
    hideModal(signupModal);
}

// Event listeners
loginBtn.addEventListener('click', () => showModal(loginModal));
signupBtn.addEventListener('click', () => showModal(signupModal));
ctaBtn.addEventListener('click', () => showModal(signupModal));

closeLogin.addEventListener('click', () => hideModal(loginModal));
closeSignup.addEventListener('click', () => hideModal(signupModal));

modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
        hideAllModals();
    }
});

switchToSignup.addEventListener('click', (e) => {
    e.preventDefault();
    hideModal(loginModal);
    showModal(signupModal);
});

switchToLogin.addEventListener('click', (e) => {
    e.preventDefault();
    hideModal(signupModal);
    showModal(loginModal);
});

// Form submissions
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Show loading state
    const submitBtn = loginForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Loading...';
    
    // Attempt login with Firebase
    const result = await signInWithEmail(email, password);
    
    if (result.success) {
        // Redirect to rasin.pyebwa.com after successful login
        window.location.href = 'https://rasin.pyebwa.com';
    } else {
        // Show error message
        alert(result.error);
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
    }
});

signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('signupConfirm').value;
    
    // Validate passwords match
    if (password !== confirmPassword) {
        const errorMsg = currentLang === 'en' ? 'Passwords do not match!' : 
                        currentLang === 'fr' ? 'Les mots de passe ne correspondent pas!' : 
                        'Mo pas yo pa menm!';
        alert(errorMsg);
        return;
    }
    
    // Show loading state
    const submitBtn = signupForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = currentLang === 'en' ? 'Creating account...' : 
                           currentLang === 'fr' ? 'Création du compte...' : 
                           'N ap kreye kont lan...';
    
    // Attempt signup with Firebase
    const result = await signUpWithEmail(email, password, name);
    
    if (result.success) {
        // Show success message
        const successMsg = currentLang === 'en' ? 'Account created successfully! Redirecting...' : 
                          currentLang === 'fr' ? 'Compte créé avec succès! Redirection...' : 
                          'Kont lan kreye avèk siksè! N ap redirijé w...';
        alert(successMsg);
        
        // Auto-login and redirect
        setTimeout(() => {
            window.location.href = 'https://rasin.pyebwa.com';
        }, 1500);
    } else {
        // Show error message
        alert(result.error);
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
    }
});

// Initialize language on load
updateLanguage();